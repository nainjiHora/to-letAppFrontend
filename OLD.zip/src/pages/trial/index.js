import TrialLayout from "../../components/layout/TrialLayout"
const Home = ()=>{

    return(
        <TrialLayout>
        <h1>Welcome To Trial User</h1>
        </TrialLayout>
    )

};

export default Home ; 
