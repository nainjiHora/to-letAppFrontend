import './home.css'
function NewHome(){
    return (<>
        <figure>
    <img src="https://picsum.photos/id/287/250/300" alt="Mountains" />
    <figcaption>The Day</figcaption>
</figure>
<figure >
    <img src="https://picsum.photos/id/475/250/300" alt="Mountains" />
    <figcaption>The Night</figcaption>
</figure>
   </> )
}
export default NewHome