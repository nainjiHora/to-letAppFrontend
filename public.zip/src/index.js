import React from 'react';
import ReactDOM from 'react-dom';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import { AuthProvider } from "./context/auth";
// import './index.css';
// import App from './Home';
// // import reportWebVitals from './reportWebVitals';
// import SignIn from './pages/signin';
// import SignUp from './pages/signup';
// import Home from "./pages/home";
// import AdminPage from "./pages/admin"
// import SubscriberPage from "./pages/subscriber"
// import TrialPage from "./pages/trial"
// import UserPage from "./pages/user"
// import Navigation  from './components/header/Navigation';
// import SubscriberForm from "./pages/subscriber/form"
// import SubscriberPayments from  "./pages/subscriber/payments"
// import SubsrcriberListings from "./pages/subscriber/post"
// import SubscriberProfile from "./pages/subscriber/profile"
// import SubscriberPricing from "./pages/subscriber/pricing"
// import Main from './pages/main';
import App from "./App"
ReactDOM.render(<App />, document.getElementById('root'));
// reportWebVitals();
