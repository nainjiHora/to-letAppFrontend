export const GoogleMapsAPI = 'AIzaSyAQqeKk0d6rogOH8tRwBM8XgU8ilne5DMc';
