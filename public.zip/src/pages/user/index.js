import UserLayout from "../../components/layout/UserLayout"
const Home = ()=>{

    return(
        <UserLayout>
        <h1>Welcome To Non - Trial User</h1>
        </UserLayout>
    )

};

export default Home ; 
