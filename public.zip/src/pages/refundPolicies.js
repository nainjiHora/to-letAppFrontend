import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
function Refund(){
    return(
    <Container className='terms-condition'>
      <Row className="mt-3">
        <Col>
          <h3>Refund Policies</h3>
          <p>Last updated: May 29, 2023</p>
          
        </Col>
      </Row>

      <Row className="mt-4">
        <Col>
          <h5>1. We are not responsible for any loss of money during transactions</h5>

        </Col>
      </Row>

      <Row className="my-5">
        <Col>
          <h5>2. Money is taken only for using the platform soo once If payment is done then no refund is their use platform and services for the time period for which u have paid</h5>
          
         

         
        </Col>
      </Row>

 


</Container>)
}
export default Refund